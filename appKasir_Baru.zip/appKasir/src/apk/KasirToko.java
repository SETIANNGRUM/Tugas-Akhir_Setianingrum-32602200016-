package apk;

/**
 *
 * @author Setia N
 */
public class KasirToko extends From_Utama implements Payment {

    
   public KasirToko() {
        super();
    }
    
    /**
     *
     * @param totalAmount
     * @param paidAmount
     */
   
    public void calculatePayment(int totalAmount, int paidAmount) {
        super.jumlah_bayar.setText(Integer.toString(paidAmount));
        super.jumlah_harga.setText(Integer.toString(totalAmount));

        Pembayaran pembayaran;
       pembayaran = new Pembayaran();
        pembayaran.calculatePayment(totalAmount, paidAmount);

        if (pembayaran.getKembalian() >= 0) {
            super.jumlah_kembalian.setText(Integer.toString(pembayaran.getKembalian()));
        } else {
            super.jumlah_kembalian.setText("Uang Anda Kurang");
        }
    }

    // Polymorphic method overriding
    public void printReceipt() {
        System.out.println("Printing Receipt...");
        // Code for printing receipt
    }

    public void processPayment(int totalAmount, int paidAmount) {
        calculatePayment(totalAmount, paidAmount);
        printReceipt();
    }

    public String getSelectedNamaBarang() {
        return (String) super.nama_barang.getSelectedItem();
    }

    public void setSelectedNamaBarang(String namaBarang) {
        super.nama_barang.setSelectedItem(namaBarang);
    }

    // Getter and Setter for GUI components
    public String getJumlahBayarText() {
        return super.jumlah_bayar.getText();
    }

    public void setJumlahBayarText(String text) {
        super.jumlah_bayar.setText(text);
    }

    public String getJumlahHargaText() {
        return super.jumlah_harga.getText();
    }

    public void setJumlahHargaText(String text) {
        super.jumlah_harga.setText(text);
    }

    public String getJumlahKembalianText() {
        return super.jumlah_kembalian.getText();
    }

    public void setJumlahKembalianText(String text) {
        super.jumlah_kembalian.setText(text);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new KasirToko().setVisible(true);
            }
        });
    }
}
