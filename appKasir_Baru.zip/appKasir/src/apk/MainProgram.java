package apk;

public class MainProgram {
    public static void main(String[] args) {
        // Inisialisasi objek KasirToko
        KasirToko kasirToko = new KasirToko();

        // Contoh pengaturan nilai
        int totalAmount = 0 ;
        int paidAmount = 0 ;

        // Proses pembayaran
        kasirToko.processPayment(totalAmount, paidAmount);

        // Contoh penggunaan getter
        String selectedNamaBarang = kasirToko.getSelectedNamaBarang();
        System.out.println("Selected Barang: " + selectedNamaBarang);

        // Contoh penggunaan setter
        kasirToko.setSelectedNamaBarang("Barang Baru");

        // Memanggil method lain jika diperlukan
        // kasirToko.methodLain();

        // Menampilkan GUI (jendela)
        java.awt.EventQueue.invokeLater(() -> {
            kasirToko.setVisible(true);
        });
    }
}
