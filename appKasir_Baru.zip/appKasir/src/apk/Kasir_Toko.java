package apk;

public class Kasir_Toko extends From_Utama implements Payment {

    /*public Kasir_Toko) static {
    super();
    }*/

    /**
     *
     * @param totalAmount
     * @param paidAmount
     */


    
    @Override
    public void calculatePayment(int totalAmount, int paidAmount) {
        super.jumlah_bayar.setText(Integer.toString(paidAmount));
        super.jumlah_harga.setText(Integer.toString(totalAmount));

        Pembayaran pembayaran = new Pembayaran();
        pembayaran.calculatePayment(totalAmount, paidAmount);

        if (pembayaran.getKembalian() >= 0) {
            super.jumlah_kembalian.setText(Integer.toString(pembayaran.getKembalian()));
        } else {
            super.jumlah_kembalian.setText("Uang Anda Kurang");
        }
    }

    public void printReceipt() {
        System.out.println("Printing Receipt...");
        // Code for printing receipt
    }

    public void processPayment(int totalAmount, int paidAmount) {
        calculatePayment(totalAmount, paidAmount);
        printReceipt();
    }

    public String getSelectedNamaBarang() {
        return (String) super.nama_barang.getSelectedItem();
    }

    public void setSelectedNamaBarang(String namaBarang) {
        super.nama_barang.setSelectedItem(namaBarang);
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new KasirToko().setVisible(true);
        });
    }
}
