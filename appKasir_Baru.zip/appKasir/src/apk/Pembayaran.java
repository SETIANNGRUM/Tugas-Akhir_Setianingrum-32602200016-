package apk;

class Pembayaran implements Payment {
    private int jumlahBayar;
    private int kembalian;

    // Getter and Setter for encapsulation
    public int getJumlahBayar() {
        return jumlahBayar;
    }

    public void setJumlahBayar(int jumlahBayar) {
        this.jumlahBayar = jumlahBayar;
    }

    public int getKembalian() {
        return kembalian;
    }

    public void setKembalian(int kembalian) {
        this.kembalian = kembalian;
    }

    
    public void calculatePayment(int totalAmount, int paidAmount) {
        if (paidAmount >= totalAmount) {
            setKembalian(paidAmount - totalAmount);
        } else {
            setKembalian(-1); // Indicates insufficient payment
        }
    }
}
