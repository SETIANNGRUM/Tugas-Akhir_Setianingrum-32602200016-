/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package apk;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Setia N
 */
public class PembayaranNGTest {
    
    public PembayaranNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of getJumlahBayar method, of class Pembayaran.
     */
    @Test
    public void testGetJumlahBayar() {
        System.out.println("getJumlahBayar");
        Pembayaran instance = new Pembayaran();
        int expResult = 0;
        int result = instance.getJumlahBayar();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahBayar method, of class Pembayaran.
     */
    @Test
    public void testSetJumlahBayar() {
        System.out.println("setJumlahBayar");
        int jumlahBayar = 0;
        Pembayaran instance = new Pembayaran();
        instance.setJumlahBayar(jumlahBayar);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getKembalian method, of class Pembayaran.
     */
    @Test
    public void testGetKembalian() {
        System.out.println("getKembalian");
        Pembayaran instance = new Pembayaran();
        int expResult = 0;
        int result = instance.getKembalian();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setKembalian method, of class Pembayaran.
     */
    @Test
    public void testSetKembalian() {
        System.out.println("setKembalian");
        int kembalian = 0;
        Pembayaran instance = new Pembayaran();
        instance.setKembalian(kembalian);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculatePayment method, of class Pembayaran.
     */
    @Test
    public void testCalculatePayment() {
        System.out.println("calculatePayment");
        int totalAmount = 0;
        int paidAmount = 0;
        Pembayaran instance = new Pembayaran();
        instance.calculatePayment(totalAmount, paidAmount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
