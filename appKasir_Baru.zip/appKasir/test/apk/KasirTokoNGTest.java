/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package apk;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Setia N
 */
public class KasirTokoNGTest {
    
    public KasirTokoNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of calculatePayment method, of class KasirToko.
     */
    @Test
    public void testCalculatePayment() {
        System.out.println("calculatePayment");
        int totalAmount = 0;
        int paidAmount = 0;
        KasirToko instance = new KasirToko();
        instance.calculatePayment(totalAmount, paidAmount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of printReceipt method, of class KasirToko.
     */
    @Test
    public void testPrintReceipt() {
        System.out.println("printReceipt");
        KasirToko instance = new KasirToko();
        instance.printReceipt();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of processPayment method, of class KasirToko.
     */
    @Test
    public void testProcessPayment() {
        System.out.println("processPayment");
        int totalAmount = 0;
        int paidAmount = 0;
        KasirToko instance = new KasirToko();
        instance.processPayment(totalAmount, paidAmount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSelectedNamaBarang method, of class KasirToko.
     */
    @Test
    public void testGetSelectedNamaBarang() {
        System.out.println("getSelectedNamaBarang");
        KasirToko instance = new KasirToko();
        String expResult = "";
        String result = instance.getSelectedNamaBarang();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSelectedNamaBarang method, of class KasirToko.
     */
    @Test
    public void testSetSelectedNamaBarang() {
        System.out.println("setSelectedNamaBarang");
        String namaBarang = "";
        KasirToko instance = new KasirToko();
        instance.setSelectedNamaBarang(namaBarang);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getJumlahBayarText method, of class KasirToko.
     */
    @Test
    public void testGetJumlahBayarText() {
        System.out.println("getJumlahBayarText");
        KasirToko instance = new KasirToko();
        String expResult = "";
        String result = instance.getJumlahBayarText();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahBayarText method, of class KasirToko.
     */
    @Test
    public void testSetJumlahBayarText() {
        System.out.println("setJumlahBayarText");
        String text = "";
        KasirToko instance = new KasirToko();
        instance.setJumlahBayarText(text);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getJumlahHargaText method, of class KasirToko.
     */
    @Test
    public void testGetJumlahHargaText() {
        System.out.println("getJumlahHargaText");
        KasirToko instance = new KasirToko();
        String expResult = "";
        String result = instance.getJumlahHargaText();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahHargaText method, of class KasirToko.
     */
    @Test
    public void testSetJumlahHargaText() {
        System.out.println("setJumlahHargaText");
        String text = "";
        KasirToko instance = new KasirToko();
        instance.setJumlahHargaText(text);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getJumlahKembalianText method, of class KasirToko.
     */
    @Test
    public void testGetJumlahKembalianText() {
        System.out.println("getJumlahKembalianText");
        KasirToko instance = new KasirToko();
        String expResult = "";
        String result = instance.getJumlahKembalianText();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahKembalianText method, of class KasirToko.
     */
    @Test
    public void testSetJumlahKembalianText() {
        System.out.println("setJumlahKembalianText");
        String text = "";
        KasirToko instance = new KasirToko();
        instance.setJumlahKembalianText(text);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class KasirToko.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        KasirToko.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
