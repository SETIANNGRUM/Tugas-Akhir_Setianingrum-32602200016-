/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package apk;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Setia N
 */
public class PembayaranTest {
    
    public PembayaranTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getJumlahBayar method, of class Pembayaran.
     */
    @Test
    public void testGetJumlahBayar() {
        System.out.println("getJumlahBayar");
        Pembayaran instance = new Pembayaran();
        int expResult = 0;
        int result = instance.getJumlahBayar();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahBayar method, of class Pembayaran.
     */
    @Test
    public void testSetJumlahBayar() {
        System.out.println("setJumlahBayar");
        int jumlahBayar = 0;
        Pembayaran instance = new Pembayaran();
        instance.setJumlahBayar(jumlahBayar);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getKembalian method, of class Pembayaran.
     */
    @Test
    public void testGetKembalian() {
        System.out.println("getKembalian");
        Pembayaran instance = new Pembayaran();
        int expResult = 0;
        int result = instance.getKembalian();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setKembalian method, of class Pembayaran.
     */
    @Test
    public void testSetKembalian() {
        System.out.println("setKembalian");
        int kembalian = 0;
        Pembayaran instance = new Pembayaran();
        instance.setKembalian(kembalian);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculatePayment method, of class Pembayaran.
     */
    @Test
    public void testCalculatePayment() {
        System.out.println("calculatePayment");
        int totalAmount = 0;
        int paidAmount = 0;
        Pembayaran instance = new Pembayaran();
        instance.calculatePayment(totalAmount, paidAmount);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
