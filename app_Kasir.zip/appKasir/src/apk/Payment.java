package apk;

interface Payment {
    void calculatePayment(int totalAmount, int paidAmount);
    class Pembayaran implements Payment {
    private int jumlahBayar;
    private int kembalian;

    public int getJumlahBayar() {
        return jumlahBayar;
    }

    public void setJumlahBayar(int jumlahBayar) {
        this.jumlahBayar = jumlahBayar;
    }

    public int getKembalian() {
        return kembalian;
    }

    public void setKembalian(int kembalian) {
        this.kembalian = kembalian;
    }

    @Override
    public void calculatePayment(int totalAmount, int paidAmount) {
        if (paidAmount >= totalAmount) {
            setKembalian(paidAmount - totalAmount);
        } else {
            setKembalian(-1);
        }
    }
}

}
